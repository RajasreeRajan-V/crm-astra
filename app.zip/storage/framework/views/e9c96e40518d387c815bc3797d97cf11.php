 

<?php $__env->startSection('content'); ?>   
<!-- Main Content -->
<style>
    .card {
        width: 80%; /* Adjust the width as needed */
        max-width: 800px; /* Optional: Set a maximum width for larger screens */
        margin: 20px auto; /* Center the card */
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
</style>
<div class="content mt-5">
    <div class="card">
        <div class="card-header">
            Update Lead Status
        </div>
        <div class="card-body">
            <h2>Update Status for <strong><?php echo e($lead->name); ?></strong></h2>

            <!-- Display error alert if the rate cannot be changed -->
            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('agent.lead.update-status.submit', $lead->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <!-- Status Dropdown -->
                <div class="form-group">
                    <label for="status" class="form-label">Lead Status</label>
                    <select name="status" id="status" class="form-select" required>
                        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($status); ?>" <?php echo e($lead->status == $status ? 'selected' : ''); ?>>
                                <?php echo e(ucfirst($status)); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <br>

                <!-- Rate Field (Visible only when status is 'closed') -->
                <div id="rate-field" class="form-group" style="display: none;">
                    <label for="rate" class="form-label">Rate</label>
                    <input type="number" name="rate" id="rate" class="form-control"
                           value="<?php echo e(old('rate', $lead->rate)); ?>"
                           placeholder="Enter rate" min="0" step="0.01">
                    <?php $__errorArgs = ['rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <br>
                <div id="deal-item-field" class="form-group" style="display: none;">
                    <label for="deal_item" class="form-label">Deal Item</label>
                    <input type="text" name="deal_item" id="deal_item" class="form-control"
                    value="<?php echo e(old('deal_item', $lead->deal_item)); ?>"
                    placeholder="Enter deal item">
                    <?php $__errorArgs = ['deal_item'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button type="submit" class="btn btn-primary mt-3">Update Lead</button>
            </form>

            <!-- Back to Lead Details Button -->
            <a href="<?php echo e(route('agent.lead.details', $lead->id)); ?>" class="btn btn-secondary mt-3">Back to Lead Details</a>
        </div>
    </div>
</div>

<!-- JavaScript to toggle Rate field visibility -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const statusDropdown = document.getElementById('status');
        const rateField = document.getElementById('rate-field');
        const dealItemField = document.getElementById('deal-item-field');

        // Function to toggle fields
        const toggleFields = () => {
            if (statusDropdown.value === 'closed') {
                rateField.style.display = 'block';
                dealItemField.style.display = 'block';
            } else {
                rateField.style.display = 'none';
                dealItemField.style.display = 'none';
            }
        };

        // Initialize on page load
        toggleFields();

        // Update visibility when status changes
        statusDropdown.addEventListener('change', toggleFields);
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('agentlogin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/astradevelops/shabin.astradevelops.in/telecall_crm/resources/views/agentlogin/update-status.blade.php ENDPATH**/ ?>