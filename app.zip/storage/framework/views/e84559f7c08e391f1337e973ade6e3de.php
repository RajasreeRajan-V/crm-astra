<?php echo e($slot); ?>

<?php /**PATH /home/astradevelops/shabin.astradevelops.in/telecall_crm/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>