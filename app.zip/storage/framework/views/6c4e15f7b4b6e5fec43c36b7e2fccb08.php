

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1>Edit Call Log</h1>
    <form method="POST" action="<?php echo e(route('agent.calllog.update', $callLog->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="lead_id" class="form-label">Lead ID</label>
            <input type="text" name="lead_id" id="lead_id" class="form-control" value="<?php echo e($callLog->lead_id); ?>" readonly>
        </div>
        <div class="mb-3">
            <label for="call_time" class="form-label">Call Time</label>
            <input type="datetime-local" name="call_time" id="call_time" class="form-control" value="<?php echo e(\Carbon\Carbon::parse($callLog->call_time)->format('Y-m-d\TH:i')); ?>" required>
        </div>
        <div class="mb-3">
            <label for="duration" class="form-label">Duration</label>
            <input type="text" name="duration" id="duration" class="form-control" value="<?php echo e($callLog->duration); ?>" required>
        </div>
        <div class="mb-3">
            <label for="notes" class="form-label">Notes</label>
            <textarea name="notes" id="notes" class="form-control"><?php echo e($callLog->notes); ?></textarea>
        </div>

        <div class="mb-3">
            <label for="outcome" class="form-label">Outcome</label>
            <select name="outcome" id="outcome" class="form-control" required>
                <option value="">Select outcome</option>
                <option value="not interested" <?php echo e($callLog->outcome == 'not interested' ? 'selected' : ''); ?>>Not Interested</option>
                <option value="interested" <?php echo e($callLog->outcome == 'interested' ? 'selected' : ''); ?>>Interested</option>
                <option value="follow-up" <?php echo e($callLog->outcome == 'follow-up' ? 'selected' : ''); ?>>Follow-Up</option>
                <option value="closed" <?php echo e($callLog->outcome == 'closed' ? 'selected' : ''); ?>>Closed</option>
            </select>
        </div>

        <div class="mb-3" id="follow_up_date_container" style="display: none;">
            <label for="follow_up_date" class="form-label">Follow-Up Date</label>
            <input type="date" name="follow_up_date" id="follow_up_date" class="form-control"
                value="<?php echo e(old('follow_up_date', optional($callLog->lead)->follow_up_date ? \Carbon\Carbon::parse($callLog->lead->follow_up_date)->format('Y-m-d') : '')); ?>">
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>


<script>
    function toggleOutcomeFields() {
        const outcome = document.getElementById('outcome').value;
        document.getElementById('follow_up_date_container').style.display =
            (outcome === 'interested' || outcome === 'follow-up') ? 'block' : 'none';
        document.getElementById('closed_fields').style.display =
            (outcome === 'closed') ? 'block' : 'none';
    }

    document.addEventListener('DOMContentLoaded', function () {
        toggleOutcomeFields();
        document.getElementById('outcome').addEventListener('change', toggleOutcomeFields);
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('agentlogin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/astradevelops/shabin.astradevelops.in/telecall_crm/resources/views/agentlogin/calllogedit.blade.php ENDPATH**/ ?>