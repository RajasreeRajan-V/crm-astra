

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1 class="mb-4">All Transactions</h1>

    <!-- Search & Filter Form -->
    <form action="<?php echo e(route('transactions.index')); ?>" method="GET" class="row g-3 align-items-end">
        <!-- Search Input -->
        <div class="col-md-3">
            <label for="search" class="form-label">Search (Lead Name or Deal Item)</label>
            <input type="text" name="search" class="form-control" placeholder="Search by Lead Name or Deal Item" value="<?php echo e(request('search')); ?>">
        </div>

        <!-- Agent Filter -->
        <div class="col-md-3">
            <label for="agent_id" class="form-label">Filter by Agent</label>
            <select name="agent_id" id="agentFilter" class="form-select">
                <option value="">All Agents</option>
                <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($agent->id); ?>" <?php echo e(request('agent_id') == $agent->id ? 'selected' : ''); ?>>
                        <?php echo e($agent->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Start Date Filter -->
        <div class="col-md-2">
            <label for="start_date" class="form-label">Start Date</label>
            <input type="date" name="start_date" class="form-control" value="<?php echo e(request('start_date')); ?>">
        </div>

        <!-- End Date Filter -->
        <div class="col-md-2">
            <label for="end_date" class="form-label">End Date</label>
            <input type="date" name="end_date" class="form-control" value="<?php echo e(request('end_date')); ?>">
        </div>

        <!-- Buttons -->
        <div class="col-md-2 d-flex gap-2">
            <button type="submit" class="btn btn-primary">Search</button>
            <a href="<?php echo e(route('transactions.index')); ?>" class="btn btn-secondary">Reset</a>
        </div>
    </form>

    <div class="card mt-4">
        <div class="card-body">
            <?php if($transactions->isEmpty()): ?>
                <p class="text-muted">No transactions available.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-dark">
                            <tr>
                                <th>#</th>
                                <th>Lead</th>
                                <th>Agent</th>
                                <th>Amount Paid</th>
                                <th>Previous Balance</th>
                                <th>New Balance</th>
                                <th>Date</th>
                                <th>Deal Item</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($transaction->lead->name); ?></td>
                                    <td><?php echo e($transaction->updatedBy->name); ?></td>
                                    <td><?php echo e($transaction->previous_value - $transaction->new_value); ?></td>
                                    <td><?php echo e($transaction->previous_value); ?></td>
                                    <td><?php echo e($transaction->new_value); ?></td>
                                    <td><?php echo e($transaction->created_at->format('d-m-Y H:i:s')); ?></td>
                                    <td><?php echo e($transaction->lead->deal_item); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php echo e($transactions->links('pagination::bootstrap-5')); ?>

            <?php endif; ?>
        </div>
    </div>
</div>

<script>
    document.getElementById('agentFilter').addEventListener('change', function() {
        this.form.submit(); // Auto-submit when agent is selected
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Desktop\New folder\telecall-crm\resources\views/agents/transactions.blade.php ENDPATH**/ ?>