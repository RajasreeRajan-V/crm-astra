
<?php $__env->startSection('title', 'Set Follow-Up'); ?>
<?php $__env->startSection('content'); ?>
<!-- Main Content -->
    <div class="form-container mt-4">
            <h2>Set Follow-Up</h2>

            <form action="<?php echo e(route('agent.lead.updateFollowUp', $lead->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <!-- Follow-Up Date -->
                <div class="mb-3">
                    <label for="follow_up_date" class="form-label">New Follow-Up Date</label>
                    <input type="date" id="follow_up_date" name="follow_up_date" class="form-control" style="max-width: 600px;" required>
                    </div>

                <!-- Buttons -->
                <button type="submit" class="btn btn-primary">Update Follow-Up</button>
                <a href="<?php echo e(route('agent.dashboard', $lead->id)); ?>" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('agentlogin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Desktop\New folder\telecall-crm\resources\views/agentlogin/set_followup.blade.php ENDPATH**/ ?>