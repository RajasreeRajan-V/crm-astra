

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="card mx-auto shadow-lg" style="max-width: 800px; border-radius: 12px; border: 2px solid transparent; background: linear-gradient(#fff, #fff) padding-box, linear-gradient(135deg, #343a40, #495057) border-box;">
        <div class="card-body p-5">
            <h4 class="card-title text-center text-dark fw-bold mb-4">Transfer Leads</h4>

            <!-- Display Validation Errors -->
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <!-- Form for selecting leads and target agent -->
            <form action="<?php echo e(route('leads.transfer.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <!-- Source Agent Selection -->
                <div class="mb-4">
                    <label for="source_agent_id" class="form-label fw-bold text-dark">Select Source User</label>
                    <select class="form-select form-select-lg rounded shadow-sm" id="source_agent_id" name="source_agent_id" onchange="fetchLeads(this.value)" required style="border: 1px solid #ddd; background-color: #f9f9f9; transition: all 0.3s;">
                        <option disabled selected>Choose a User</option>
                        <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($agent->id); ?>" <?php echo e(old('source_agent_id') == $agent->id ? 'selected' : ''); ?>><?php echo e($agent->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['source_agent_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-2"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Leads List with Checkboxes -->
                <div id="leads-list" class="mb-4" style="display: none;">
                    <label class="form-label fw-bold text-dark">Select Leads to Transfer</label>
                    <div id="leads-checkboxes" class="row gx-3 gy-3">
                        <!-- Checkboxes will be dynamically populated here -->
                    </div>
                </div>

                <!-- Target Agent Selection -->
                <div class="mb-4">
                    <label for="target_agent_id" class="form-label fw-bold text-dark">Transfer to User</label>
                    <select class="form-select form-select-lg rounded shadow-sm" id="target_agent_id" name="target_agent_id" required style="border: 1px solid #ddd; background-color: #f9f9f9; transition: all 0.3s;">
                        <option disabled selected>Choose a User</option>
                        <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($agent->id); ?>" <?php echo e(old('target_agent_id') == $agent->id ? 'selected' : ''); ?>><?php echo e($agent->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['target_agent_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-2"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Submit Button -->
                <button type="submit" class="btn btn-success btn-lg w-100 rounded-pill fw-bold" style="background: linear-gradient(135deg, #343a40, #495057); border: none; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); transition: transform 0.2s;">
                    Transfer Selected Leads
                </button>
            </form>
        </div>
    </div>
</div>

<script>
    // JavaScript to fetch leads based on selected source agent
    function fetchLeads(agentId) {
        if (!agentId) return;
        let apiUrl = "<?php echo e(url('/api/leads-by-agent')); ?>/" + agentId;  // Using full URL
        
        fetch(apiUrl)
    
            .then(response => {
                if (!response.ok) {
                    throw new Error("Network response was not ok");
                }
                return response.json();
            })
            .then(data => {
                const leadsList = document.getElementById('leads-list');
                const leadsCheckboxes = document.getElementById('leads-checkboxes');
                leadsCheckboxes.innerHTML = ''; // Clear any previous leads

                if (data.length > 0) {
                    data.forEach(lead => {
                        leadsCheckboxes.innerHTML += `
                            <div class="col-12 col-sm-6 col-md-4">
                                <div class="form-check p-2" style="background-color: #f9f9f9; border-radius: 8px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);">
                                    <input class="form-check-input" type="checkbox" name="lead_ids[]" value="${lead.id}" id="lead-${lead.id}">
                                    <label class="form-check-label fw-bold text-dark" for="lead-${lead.id}">${lead.name}</label>
                                </div>
                            </div>`;
                    });
                    leadsList.style.display = 'block'; // Show leads list
                } else {
                    leadsList.style.display = 'none'; // Hide if no leads found
                }
            })
            .catch(error => {
                console.error('Error fetching leads:', error);
            });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/astradevelops/shabin.astradevelops.in/telecall_crm/resources/views/leads/transfer.blade.php ENDPATH**/ ?>