

<?php $__env->startSection('title', 'Transactions'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1 class="mb-4">Transactions</h1>

    <div class="mb-4">
        <!-- Search & Filter Form -->
        <form action="<?php echo e(route('agent.transactions')); ?>" method="GET" class="row g-3">
            <div class="col-md-3">
                <input 
                    type="text" 
                    name="search" 
                    class="form-control" 
                    placeholder="Search by Lead Name or Deal Item" 
                    value="<?php echo e(request('search')); ?>">
            </div>

            <!-- Start Date Filter -->
            <div class="col-md-2">
                <input 
                    type="date" 
                    name="start_date" 
                    class="form-control" 
                    value="<?php echo e(request('start_date')); ?>">
            </div>

            <!-- End Date Filter -->
            <div class="col-md-2">
                <input 
                    type="date" 
                    name="end_date" 
                    class="form-control" 
                    value="<?php echo e(request('end_date')); ?>">
            </div>

            <div class="col-md-3">
                <button type="submit" class="btn btn-primary">Search</button>
                <a href="<?php echo e(route('agent.transactions')); ?>" class="btn btn-secondary">Reset</a>
            </div>
        </form>
    </div>

    <div class="text-end mb-3">
        <a href="<?php echo e(route('agent.transactions.create')); ?>" class="btn btn-primary">Add New Transaction</a>
    </div>

    <div class="card">
        <div class="card-body">
            <?php if($transactions->isEmpty()): ?>
                <p class="text-muted">No transactions available.</p>
            <?php else: ?>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Lead</th>
                            <th>Deal Rate</th>
                            <th>Amount Paid</th>
                            <th>Previous Balance</th>
                            <th>New Balance</th>
                            <th>Date</th>
                            <th>Deal Item</th>
                            <th>Notes</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($transaction->lead->name); ?></td>
                                <td><?php echo e($transaction->lead->rate); ?></td>
                                <td><?php echo e($transaction->previous_value - $transaction->new_value); ?></td>
                                <td><?php echo e($transaction->previous_value); ?></td>
                                <td><?php echo e($transaction->new_value); ?></td>
                                <td><?php echo e($transaction->created_at->format('d-m-Y H:i')); ?></td>
                                <td><?php echo e($transaction->lead->deal_item); ?></td>
                                <td><?php echo e($transaction->notes); ?></td>
                                <?php if($transaction->created_at == $transaction->lead->balanceUpdateLogs()->latest()->first()->created_at): ?> 
                                    <!-- Only show the "Edit" button for the most recent transaction -->
                                    <td><a href="<?php echo e(route('agent.transactions.edit', $transaction->id)); ?>" class="btn btn-warning btn-sm">Edit</a></td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>

                <?php echo e($transactions->links('pagination::bootstrap-5')); ?>

            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('agentlogin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/astradevelops/public_html/crm.astradevelops.in/resources/views/agentlogin/transactions/index.blade.php ENDPATH**/ ?>