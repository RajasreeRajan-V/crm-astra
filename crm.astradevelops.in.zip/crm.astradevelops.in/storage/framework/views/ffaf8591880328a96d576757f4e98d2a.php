
<?php $__env->startSection('content'); ?>
    <style>

        /* Main Content Styling */
        .form-container {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: auto;
        }

        .form-container h2 {
            margin-bottom: 30px;
        }
    </style>

    <!-- Main Content -->
    <div class="content mt-5">
        <div class="form-container">
            <h2>Add Call Log</h2>

            <form action="<?php echo e(route('agent.calllog.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <!-- Lead ID (Assigned Leads Only) -->
                <div class="mb-3">
                    <label for="lead_id" class="form-label">Lead ID</label>
                    <select id="lead_id" name="lead_id" class="form-control" required>
                        <option value="">Select a Lead</option>
                        <?php $__currentLoopData = $assignedLeads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($lead->id); ?>"><?php echo e($lead->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <!-- Agent ID (Automatically Generated) -->
                <div class="mb-3">
                    <label for="agent_id" class="form-label">Agent ID</label>
                    <input type="text" id="agent_id" name="agent_id" class="form-control" value="<?php echo e(Auth::user()->id); ?>" readonly>
                </div>

                <!-- Call Time -->
                <div class="mb-3">
                    <label for="calltime" class="form-label">Call Time</label>
                    <input type="datetime-local" id="call_time" name="call_time" class="form-control" value="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d\TH:i')); ?>" required>
                    <button type="button" class="btn btn-info mt-2" id="setNow">Now</button>
                </div>

                <!-- Duration -->
                <div class="mb-3">
                    <label for="duration" class="form-label">Duration (in minutes)</label>
                    <input type="number" id="duration" name="duration" class="form-control" required>
                </div>

                <!-- Notes -->
                <div class="mb-3">
                    <label for="notes" class="form-label">Notes</label>
                    <textarea id="notes" name="notes" class="form-control" rows="4" required></textarea>
                </div>

                <!-- Outcome -->
                <div class="mb-3">
                    <label for="outcome" class="form-label">Outcome</label>
                    <select id="outcome" name="outcome" class="form-control" required>
                        <option value="not interested">not interested</option>
                        <option value="interested">interested</option>
                        <option value="follow-up">follow-up</option>
                        <option value="closed">closed</option>
                    </select>
                </div>

                <div class="mb-3" id="follow-up-date-container" style="display: none;">
                <label for="follow_up_date" class="form-label">Follow-Up Date</label>
                <input type="date" id="follow_up_date" name="follow_up_date" class="form-control">
                </div>

                <!-- Submit Button -->
                <button type="submit" class="btn btn-success">Save Call Log</button>
                <a href="<?php echo e(route('agent.callLogs')); ?>" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('agentlogin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Desktop\New folder\telecall-crm\resources\views/agentlogin/calllogs_create.blade.php ENDPATH**/ ?>