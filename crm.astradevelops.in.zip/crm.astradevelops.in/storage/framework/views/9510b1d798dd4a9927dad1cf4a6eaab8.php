

<?php $__env->startSection('title', 'Edit Transaction'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1 class="mb-4">Edit Transaction</h1>

    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('agent.transactions.update', $transaction->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label for="lead_id" class="form-label">Lead</label>
                    <input type="text" id="lead_id" class="form-control" value="<?php echo e($transaction->lead->name); ?>" readonly>
                </div>

                <div class="mb-3">
                    <label for="amount" class="form-label">Amount Paid</label>
                    <input type="number" name="amount" id="amount" class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                        value="<?php echo e(old('amount', $transaction->previous_value - $transaction->new_value)); ?>" required>
                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


                <div class="mb-3">
                    <label for="notes" class="form-label">Notes</label>
                    <textarea name="notes" id="notes" class="form-control" rows="3"><?php echo e($transaction->notes); ?></textarea>
                </div>

                <button type="submit" class="btn btn-primary">Save Changes</button>
                <a href="<?php echo e(route('agent.transactions')); ?>" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('agentlogin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/astradevelops/shabin.astradevelops.in/telecall_crm/resources/views/agentlogin/transactions/edit.blade.php ENDPATH**/ ?>