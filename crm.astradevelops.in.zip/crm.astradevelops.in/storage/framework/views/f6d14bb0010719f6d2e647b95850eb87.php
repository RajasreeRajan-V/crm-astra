

<?php $__env->startSection('title', 'User Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1 class="mb-4 mt-3 fw-bold">User Dashboard</h1>
    <div class="row g-4">
        <!-- Performance Metrics Section -->
        <div class="col-md-6">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-primary text-white rounded-top">
                    <h5 class="mb-0">Performance Metrics</h5>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between">
                            <span>Total Leads Assigned:</span>
                            <span class="badge bg-success"><?php echo e($totalLeads); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span>Converted Leads:</span>
                            <span class="badge bg-info"><?php echo e($convertedLeads); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span>Conversion Rate:</span>
                            <span class="badge bg-warning text-dark"><?php echo e($conversionRate); ?>%</span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span>Total Calls:</span>
                            <span class="badge bg-danger"><?php echo e($totalCalls); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span>Call Success Rate:</span>
                            <span class="badge bg-success"><?php echo e($callSuccessRate); ?>%</span>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Call Logs Section -->
        <div class="col-md-6">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-primary text-white rounded-top">
                    <h5 class="mb-0">Recent Call Logs</h5>
                </div>
                <div class="card-body">
                    <ul class="list-group">
                        <?php $__empty_1 = true; $__currentLoopData = $callLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $callLog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="list-group-item">
                                <div>
                                    <strong>Lead:</strong> <?php echo e($callLog->lead->name); ?><br>
                                    <strong>Outcome:</strong> <?php echo e(ucfirst($callLog->outcome)); ?><br>
                                    <strong>Call Time:</strong> <?php echo e($callLog->call_time); ?>

                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-muted">No recent call logs available.</p>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Follow-ups Section -->
        <div class="col-md-12">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-warning text-dark rounded-top">
                    <h5 class="mb-0">Upcoming Follow-Ups</h5>
                </div>
                <div class="card-body">
                    <?php if($followUps->isEmpty()): ?>
                        <p class="text-muted">No upcoming follow-ups.</p>
                    <?php else: ?>
                        <ul class="list-group">
                            <?php $__currentLoopData = $followUps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $followUp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong>Lead:</strong> <?php echo e($followUp->name); ?><br>
                                        <strong>Follow-Up Date:</strong> <?php echo e(\Carbon\Carbon::parse($followUp->follow_up_date)->toDateString()); ?>

                                        </div>
                                    <a href="<?php echo e(route('agent.lead.followup', $followUp->id)); ?>" class="btn btn-sm btn-success">Update Follow-Up</a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Assigned Leads Section -->
        <div class="col-md-12">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-success text-white rounded-top">
                    <h5 class="mb-0">Assigned Leads</h5>
                </div>
                <div class="card-body">
                    <ul class="list-group">
                        <?php $__currentLoopData = $assignedLeads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <strong>Lead Name:</strong> <?php echo e($lead->name); ?><br>
                                    <strong>Status:</strong> <?php echo e(ucfirst($lead->status)); ?>

                                </div>
                                <a href="<?php echo e(route('agent.lead.details', $lead->id)); ?>" class="btn btn-sm btn-primary">View Details</a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('agentlogin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Desktop\New folder\telecall-crm\resources\views/agentlogin/dashboard.blade.php ENDPATH**/ ?>