
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Assigned Leads</h1>
        <a href="<?php echo e(route('agent.create.lead')); ?>" class="btn btn-success">+ Add New Lead</a>
    </div>

    <!-- Filters -->
    <form action="<?php echo e(route('agent.leads')); ?>" method="GET" id="filterForm" class="mb-4 row g-3">
        <div class="col-lg-3 col-md-4 col-sm-6">
            <select 
                name="status" 
                class="form-select" 
                aria-label="Filter by Status">
                <option value="">Filter by Status</option>
                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status); ?>" <?php echo e(request('status') === $status ? 'selected' : ''); ?>>
                        <?php echo e(ucfirst($status)); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="col-lg-3 col-md-4 col-sm-6">
            <input 
                type="text" 
                name="search" 
                class="form-control" 
                placeholder="Search by Name" 
                value="<?php echo e(request('search')); ?>">
        </div>

        <div class="col-lg-3 col-md-4 col-sm-6">
            <input 
                type="date" 
                name="start_date" 
                class="form-control" 
                value="<?php echo e(request('start_date')); ?>">
        </div>

        <div class="col-lg-3 col-md-4 col-sm-6">
            <input 
                type="date" 
                name="end_date" 
                class="form-control" 
                value="<?php echo e(request('end_date')); ?>">
        </div>

        <div class="col-lg-3 col-md-4 col-sm-12 d-flex align-items-end">
            <button type="submit" class="btn btn-primary me-2">Filter</button>
            <a href="<?php echo e(route('agent.leads')); ?>" class="btn btn-secondary">Reset</a>
        </div>
    </form>

    <!-- Display Leads -->
    <?php if($leads->isEmpty()): ?>
        <p>No leads found.</p>
    <?php else: ?>
        <div class="card">
            <div class="card-body">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Lead Name</th>
                            <th>Status</th>
                            <th>Assigned On</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($lead->name); ?></td>
                                <td><?php echo e(ucfirst($lead->status)); ?></td>
                                <td><?php echo e($lead->created_at->format('d-m-Y')); ?></td>
                                <td>
                                    <a href="<?php echo e(route('agent.lead.details', $lead->id)); ?>" class="btn btn-sm btn-primary">View Details</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('agentlogin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/astradevelops/public_html/crm.astradevelops.in/resources/views/agentlogin/leads.blade.php ENDPATH**/ ?>