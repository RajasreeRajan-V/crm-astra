
<?php $__env->startSection('content'); ?>
        <!-- Main Content -->
            <div class="container mt-5">
                <h1 class="mb-4">Assigned Leads</h1>

                <?php if($leads->isEmpty()): ?>
                    <p>No leads assigned to you.</p>
                <?php else: ?>
                    <div class="card">
                        <div class="card-body">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Lead Name</th>
                                        <th>Status</th>
                                        <th>Assigned On</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($lead->name); ?></td>
                                            <td><?php echo e(ucfirst($lead->status)); ?></td>
                                            <td><?php echo e($lead->created_at->format('d-m-Y')); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('agent.lead.details', $lead->id)); ?>" class="btn btn-sm btn-primary">View Details</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('agentlogin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Desktop\New folder\telecall-crm\resources\views/agentlogin/leads.blade.php ENDPATH**/ ?>