

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1>User Details</h1>
    <div class="card mt-3 mb-4">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($agent->name); ?></h5>
            <br>
            <p><strong>Email:</strong> <?php echo e($agent->email); ?></p>
            <p><strong>Phone No:</strong> <?php echo e($agent->phone_no); ?></p>
        </div>
    </div>

    <h2>Assigned Leads</h2>
    <?php if($agent->leads->isEmpty()): ?>
        <p>No leads assigned to this User.</p>
    <?php else: ?>
        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Contact</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $agent->leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($lead->id); ?></td>
                        <td><?php echo e($lead->name); ?></td>
                        <td><?php echo e($lead->contact); ?></td>
                        <td><?php echo e($lead->status); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
    <a href="<?php echo e(route('agents.index')); ?>" class="btn btn-secondary mt-3">Back to Users</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/astradevelops/shabin.astradevelops.in/telecall_crm/resources/views/agents/show.blade.php ENDPATH**/ ?>