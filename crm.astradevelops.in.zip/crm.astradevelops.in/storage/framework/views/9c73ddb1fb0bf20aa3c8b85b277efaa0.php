

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1>Edit Call Log</h1>
    <form method="POST" action="<?php echo e(route('agent.calllog.update', $callLog->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="lead_id" class="form-label">Lead ID</label>
            <input type="text" name="lead_id" id="lead_id" class="form-control" value="<?php echo e($callLog->lead_id); ?>" required>
        </div>
        <div class="mb-3">
            <label for="call_time" class="form-label">Call Time</label>
            <input type="datetime-local" name="call_time" id="call_time" class="form-control" value="<?php echo e($callLog->call_time); ?>" required>
        </div>
        <div class="mb-3">
            <label for="duration" class="form-label">Duration</label>
            <input type="text" name="duration" id="duration" class="form-control" value="<?php echo e($callLog->duration); ?>" required>
        </div>
        <div class="mb-3">
            <label for="notes" class="form-label">Notes</label>
            <textarea name="notes" id="notes" class="form-control" required><?php echo e($callLog->notes); ?></textarea>
        </div>
        <div class="mb-3">
            <label for="outcome" class="form-label">Outcome</label>
            <input type="text" name="outcome" id="outcome" class="form-control" value="<?php echo e($callLog->outcome); ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('agentlogin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Desktop\New folder\telecall-crm\resources\views/agentlogin/calllogedit.blade.php ENDPATH**/ ?>