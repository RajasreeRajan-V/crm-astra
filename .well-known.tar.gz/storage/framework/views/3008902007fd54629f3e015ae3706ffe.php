

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1 class="mb-4">Update Lead Status</h1>
    <!-- Filter and Search Form -->
    <form action="<?php echo e(route('leads.updateStatusIndex')); ?>" method="GET" class="mb-3">
        <div class="row align-items-end">
            <!-- Filter by Status -->
            <div class="col-md-4 mb-3">
                <label for="status" class="form-label">Filter by Status:</label>
                <select name="status" id="status" class="form-select" onchange="this.form.submit()">
                    <option value="">All</option>
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status); ?>" <?php echo e($statusFilter === $status ? 'selected' : ''); ?>>
                            <?php echo e(ucfirst($status)); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <!-- Search by Name -->
            <div class="col-md-4 mb-3">
                <label for="search_term" class="form-label">Search by Name:</label>
                <input type="text" name="search_term" id="search_term" class="form-control" value="<?php echo e(request()->search_term); ?>">
            </div>

            <!-- Search and Reset Buttons -->
            <div class="col-md-4 mb-3 d-flex justify-content-start align-items-end">
                <button type="submit" class="btn btn-primary me-2">Search</button>
                <a href="<?php echo e(route('leads.updateStatusIndex')); ?>" class="btn btn-secondary">Reset</a>
            </div>
        </div>
    </form>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Contact</th>
                <th>Current Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td> <!-- Auto-incremented ID -->
                    <td><?php echo e($lead->name); ?></td>
                    <td><?php echo e($lead->contact); ?></td>
                    <td><?php echo e(ucfirst($lead->status)); ?></td>
                    <td>
                        <a href="<?php echo e(route('leads.editStatus', $lead->id)); ?>" class="btn btn-success btn-sm">Update Status</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Desktop\New folder\telecall-crm\resources\views/leads/update-status-index.blade.php ENDPATH**/ ?>