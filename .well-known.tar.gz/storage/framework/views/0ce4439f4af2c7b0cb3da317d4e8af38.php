

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1 class="text-center mb-4 text-dark">User: <?php echo e($agent->name); ?></h1>

    <!-- Agent Performance Details -->
    <div class="row mb-5">
        <div class="col-md-4">
            <div class="card shadow-sm rounded-4">
                <div class="card-body">
                    <h5 class="card-title text-dark">Total Leads Assigned</h5>
                    <p class="card-text text-muted"><?php echo e($leadsCount); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm rounded-4">
                <div class="card-body">
                    <h5 class="card-title text-dark">Leads Converted</h5>
                    <p class="card-text text-muted"><?php echo e($leadsConverted); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm rounded-4">
                <div class="card-body">
                    <h5 class="card-title text-dark">Total Calls Made</h5>
                    <p class="card-text text-muted"><?php echo e($totalCalls); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Agent Performance Metrics -->
    <div class="row mb-5">
        <div class="col-md-4">
            <div class="card shadow-sm rounded-4">
                <div class="card-body">
                    <h5 class="card-title text-dark">Average Call Duration</h5>
                    <p class="card-text text-muted"><?php echo e($averageCallDuration); ?> mins</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm rounded-4">
                <div class="card-body">
                    <h5 class="card-title text-dark">Average Response Time to Leads</h5>
                    <p class="card-text text-muted"><?php echo e($averageResponseTime); ?> hrs</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm rounded-4">
                <div class="card-body">
                    <h5 class="card-title text-dark">Average Time to Close a Lead</h5>
                    <p class="card-text text-muted"><?php echo e($averageTimeToClose); ?> days</p>
                </div>
            </div>
        </div>
    </div>

    <div class="row mb-5">
    <div class="col-md-4">
        <div class="card shadow-sm rounded-4">
            <div class="card-body">
                <h5 class="card-title text-dark">Total Deal Amount Closed</h5>
                <p class="card-text text-muted">₹<?php echo e(number_format($totalDealAmount, 2)); ?></p>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card shadow-sm rounded-4">
            <div class="card-body">
                <h5 class="card-title text-dark">Total Revenue Generated</h5>
                <p class="card-text text-muted">₹<?php echo e(number_format($totalRevenue, 2)); ?></p>
            </div>
        </div>
    </div>
</div>

    <!-- Call Logs Section -->
    <h3 class="mb-4 text-dark">Call Logs</h3>
    <div class="table-responsive">
        <?php if($agent->callLogs->isEmpty()): ?>
            <p class="text-muted">No call logs available for this User.</p>
        <?php else: ?>
            <table class="table table-striped table-bordered shadow-sm rounded-4">
                <thead class="bg-dark text-white">
                    <tr>
                        <th>Lead Name</th>
                        <th>Call Time</th>
                        <th>Duration</th>
                        <th>Outcome</th>
                        <th>Notes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $agent->callLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $callLog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($callLog->lead->name ?? 'N/A'); ?></td>
                            <td><?php echo e($callLog->call_time); ?></td>
                            <td><?php echo e($callLog->duration); ?> mins</td>
                            <td><?php echo e($callLog->outcome); ?></td>
                            <td><?php echo e($callLog->notes); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/astradevelops/shabin.astradevelops.in/telecall_crm/resources/views/agents/details.blade.php ENDPATH**/ ?>