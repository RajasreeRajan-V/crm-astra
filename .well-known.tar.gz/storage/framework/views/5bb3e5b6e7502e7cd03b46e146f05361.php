<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\DELL\Desktop\New folder\telecall-crm\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>