

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2>Call Logs</h2>

    <!-- Filter Form -->
    <form method="GET" action="<?php echo e(route('callLogs.index')); ?>" class="mb-4">
        <div class="row g-3">
            <div class="col-md-6 col-lg-3">
                <label for="agent_id" class="form-label">Agent</label>
                <select name="agent_id" id="agent_id" class="form-select">
                    <option value="">All Agents</option>
                    <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($agent->id); ?>" <?php echo e(request('agent_id') == $agent->id ? 'selected' : ''); ?>>
                            <?php echo e($agent->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="col-md-6 col-lg-3">
                <label for="lead_search" class="form-label">Search Lead</label>
                <input type="text" name="lead_search" id="lead_search" class="form-control" placeholder="Enter lead name" value="<?php echo e(request('lead_search')); ?>">
            </div>

            <div class="col-md-6 col-lg-3">
                <label for="start_date" class="form-label">Start Date</label>
                <input type="date" name="start_date" id="start_date" class="form-control" value="<?php echo e(request('start_date')); ?>">
            </div>

            <div class="col-md-6 col-lg-3">
                <label for="end_date" class="form-label">End Date</label>
                <input type="date" name="end_date" id="end_date" class="form-control" value="<?php echo e(request('end_date')); ?>">
            </div>
        </div>

        <div class="mt-3">
            <button type="submit" class="btn btn-primary">Filter</button>
            <a href="<?php echo e(route('callLogs.index')); ?>" class="btn btn-secondary">Reset</a>
        </div>
    </form>

    <!-- Call Logs Table -->
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Lead Name</th>
                    <th>Agent Name</th>
                    <th>Call Time</th>
                    <th>Duration (mins)</th>
                    <th>Outcome</th>
                    <th>Notes</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $callLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($log->lead->name ?? 'N/A'); ?></td>
                        <td><?php echo e($log->agent->name ?? 'N/A'); ?></td>
                        <td><?php echo e($log->call_time); ?></td>
                        <td><?php echo e($log->duration); ?></td>
                        <td><?php echo e(ucfirst($log->outcome)); ?></td>
                        <td><?php echo e($log->notes); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center">No call logs found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination Links -->
    <div class="d-flex justify-content-center">
    <nav>
        <?php echo e($callLogs->links('pagination::bootstrap-5')); ?>

    </nav>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/astradevelops/shabin.astradevelops.in/telecall_crm/resources/views/calls/index.blade.php ENDPATH**/ ?>