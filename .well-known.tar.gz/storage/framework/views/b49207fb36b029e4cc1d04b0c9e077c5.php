<!-- resources/views/agents/performance.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1 class="mb-4">Agent Performance</h1>
    
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Agent Name</th>
                    <th>Total Leads Assigned</th>
                    <th>Leads Converted</th>
                    <th>Conversion Rate (%)</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($agent->name); ?></td>
                        <td><?php echo e($agent->leads_count); ?></td> <!-- Assuming you calculate leads count in the controller -->
                        <td><?php echo e($agent->leads_converted); ?></td> <!-- Assuming this field is calculated as well -->
                        <td>
                            <?php echo e($agent->leads_count > 0 ? round(($agent->leads_converted / $agent->leads_count) * 100, 2) : 0); ?>

                        </td>
                        <td>
                            <a href="<?php echo e(route('agents.details', $agent->id)); ?>" class="btn btn-info btn-sm">View Details</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Desktop\New folder\telecall-crm\resources\views/agents/performance.blade.php ENDPATH**/ ?>