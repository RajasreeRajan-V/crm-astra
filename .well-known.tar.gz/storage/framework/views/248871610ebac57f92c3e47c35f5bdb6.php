

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1 class="mb-4">Dashboard Overview</h1>

    <!-- Summary Section -->
    <div class="row mb-5">
        <div class="col-md-4 col-sm-12 mb-3">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <h5>Total Leads</h5>
                    <p class="display-4"><?php echo e($totalLeads); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-12 mb-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h5>Total Agents</h5>
                    <p class="display-4"><?php echo e($totalAgents); ?></p>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-12 mb-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <h5>Total Call Logs</h5>
                    <p class="display-4"><?php echo e($totalCallLogs); ?></p>
                </div>
            </div>
        </div>
    </div>

    <div class="row mb-5">
        <div class="col-md-4 col-sm-12 mb-3">
            <div class="card bg-warning text-dark">
                <div class="card-body">
                    <h5>Lead Conversion Rate</h5>
                    <p class="display-4"><?php echo e(number_format($conversionRate, 2)); ?>%</p>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-12 mb-3">
            <div class="card bg-secondary text-white">
                <div class="card-body">
                    <h5>Pending Follow-ups</h5>
                    <p class="display-4"><?php echo e($pendingFollowupsCount); ?></p>
                </div>
            </div>
        </div>
    </div>

    <h3>Lead Source Breakdown</h3>
    <div class="row">
        <?php $__currentLoopData = $leadSourceBreakdown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-6 col-lg-3 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h5><?php echo e(ucfirst($source)); ?></h5>
                        <h4><?php echo e($count); ?></h4>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Lead Status Count Section -->
    <h3>Lead Status Counts</h3>
    <div class="row mb-5">
        <?php $__currentLoopData = $leadStatusCounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 col-sm-6 col-lg-3 mb-3">
                    <div class="card">
                    <div class="card-body">
                        <h5><?php echo e(ucfirst($status)); ?></h5>
                        <h4><?php echo e($count); ?></h4>
                        <div class="d-flex justify-content-between align-items-center">
                            <a href="<?php echo e(route('dashboard.leadsByStatus', $status)); ?>" class="btn btn-primary btn-sm">View Details</a>
                            <!-- Info icon to open modal -->
                            <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#agentCountsModal-<?php echo e($status); ?>">
                                <i class="fas fa-info-circle"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal for agent count by lead status -->
            <div class="modal fade" id="agentCountsModal-<?php echo e($status); ?>" tabindex="-1" aria-labelledby="agentCountsModalLabel-<?php echo e($status); ?>" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="agentCountsModalLabel-<?php echo e($status); ?>">Agent Lead Count for <?php echo e(ucfirst($status)); ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <?php
                                $agentLeadCounts = \App\Models\Lead::where('status', $status)
                                    ->selectRaw('assigned_agent_id, COUNT(*) as count')
                                    ->groupBy('assigned_agent_id')
                                    ->with('agent')
                                    ->get();
                            ?>
                            <ul>
                                <?php $__currentLoopData = $agentLeadCounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agentCount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <?php echo e($agentCount->agent->name ?? 'Unassigned'); ?>: <?php echo e($agentCount->count); ?> leads
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="row">
        <div class="col-md-4 col-sm-12 mb-3">
            <div class="card bg-warning text-dark">
                <div class="card-body">
                    <h5>Call Success Rate</h5>
                    <p class="display-4"><?php echo e(number_format($callSuccessRate, 2)); ?>%</p>
                </div>
            </div>
        </div>
    <div class="col-md-4 col-sm-12 mb-3">
        <div class="card bg-dark text-white">
            <div class="card-body">
                <h5>Total Deal Amount</h5>
                <p class="display-4">$<?php echo e(number_format($totalDealAmount)); ?></p>
            </div>
        </div>
    </div>

    <div class="col-md-4 col-sm-12 mb-3">
        <div class="card bg-danger text-white">
            <div class="card-body">
                <h5>Total Revenue</h5>
                <p class="display-4">$<?php echo e(number_format($totalRevenue)); ?></p>
            </div>
        </div>
    </div>
</div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Desktop\New folder\telecall-crm\resources\views/dashboard/index.blade.php ENDPATH**/ ?>