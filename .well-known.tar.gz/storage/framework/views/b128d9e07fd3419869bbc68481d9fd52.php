

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="card shadow-lg rounded-4" style="border: 2px solid #ddd;">
        <div class="card-body p-5">
            <h5 class="card-title text-center" style="color: #343a40;">Unassigned Leads</h5>

            <!-- Display success or error messages -->
            <?php if(session('success')): ?>
                <div class="alert alert-success fade show" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php elseif(session('error')): ?>
                <div class="alert alert-danger fade show" role="alert">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <!-- Display validation errors -->
            <?php if($errors->any()): ?>
                <div class="alert alert-danger fade show" role="alert">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <!-- Form for transferring unassigned leads -->
            <form action="<?php echo e(route('leads.unassigned.transfer')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <!-- List of unassigned leads with checkboxes -->
                <div class="mb-4">
                    <label class="form-label fw-bold" style="color: #343a40;">Select Leads to Transfer</label>
                    <?php if($unassignedLeads->isEmpty()): ?>
                        <p class="text-muted">No unassigned leads found.</p>
                    <?php else: ?>
                        <?php $__currentLoopData = $unassignedLeads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-check mb-3">
                                <input class="form-check-input" type="checkbox" name="lead_ids[]" value="<?php echo e($lead->id); ?>" id="lead-<?php echo e($lead->id); ?>">
                                <label class="form-check-label" for="lead-<?php echo e($lead->id); ?>" style="font-weight: 500;"><?php echo e($lead->name); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>

                <!-- Target agent selection -->
                <div class="mb-4">
                    <label for="target_agent_id" class="form-label fw-bold" style="color: #343a40;">Transfer to User</label>
                    <select class="form-select form-select-lg shadow-sm rounded-3" id="target_agent_id" name="target_agent_id" required>
                        <option disabled selected>Choose a User</option>
                        <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($agent->id); ?>"><?php echo e($agent->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <!-- Transfer button -->
                <button type="submit" class="btn w-100" style="background: linear-gradient(135deg, #343a40, #495057); color: white; border-radius: 25px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); padding: 10px 20px; transition: transform 0.2s;">
                    <strong>Transfer Leads</strong>
                </button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/astradevelops/public_html/crm.astradevelops.in/resources/views/leads/unassigned.blade.php ENDPATH**/ ?>