

<?php $__env->startSection('title', 'Edit Lead Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="content-container mt-5">
    <div class="card mx-auto" style="max-width: 600px;">
        <div class="card-header">
            <h1 class="form-title">Edit Lead Details</h1>
        </div>
        <div class="card-body">
            <!-- Display success or error messages -->
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php elseif(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <!-- Edit Lead Form -->
            <form action="<?php echo e(route('agent.leads.update', $lead->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?> <!-- For PUT request -->

                <!-- Lead Name -->
                <div class="mb-3">
                    <label for="name" class="form-label">Lead Name</label>
                    <input type="text" id="name" name="name" class="form-control" value="<?php echo e(old('name', $lead->name)); ?>" required>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Contact Number -->
                <div class="mb-3">
                    <label for="contact" class="form-label">Contact Number</label>
                    <input type="text" id="contact" name="contact" class="form-control" value="<?php echo e(old('contact', $lead->contact)); ?>" required>
                    <?php $__errorArgs = ['contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Lead Source (Dropdown) -->
                <div class="mb-3">
                    <label for="source" class="form-label">Lead Source</label>
                    <select id="source" name="source" class="form-control" required>
                        <option value="Website" <?php echo e(old('source', $lead->source) == 'Website' ? 'selected' : ''); ?>>Website</option>
                        <option value="Social Media" <?php echo e(old('source', $lead->source) == 'Social Media' ? 'selected' : ''); ?>>Social Media</option>
                        <option value="Email" <?php echo e(old('source', $lead->source) == 'Email' ? 'selected' : ''); ?>>Email</option>
                        <option value="Referral" <?php echo e(old('source', $lead->source) == 'Referral' ? 'selected' : ''); ?>>Referral</option>
                        <option value="Advertisement" <?php echo e(old('source', $lead->source) == 'Advertisement' ? 'selected' : ''); ?>>Advertisement</option>
                    </select>
                    <?php $__errorArgs = ['source'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Lead Status (Uneditable) -->
                <div class="mb-3">
                    <label for="status" class="form-label">Lead Status</label>
                    <input type="text" id="status" name="status" class="form-control" value="<?php echo e(ucfirst($lead->status)); ?>" disabled>
                </div>

                <!-- Rate and Balance (Rate Uneditable if Status is Closed) -->
                <?php if($lead->status === 'closed'): ?>
                    <div class="mb-3">
                        <label for="rate" class="form-label">Rate</label>
                        <input type="number" id="rate" class="form-control" value="<?php echo e($lead->rate); ?>" disabled>
                        <input type="hidden" name="rate" value="<?php echo e($lead->rate); ?>">
                    </div>
                    <div class="mb-3">
                    <label for="balance" class="form-label">Balance</label>
                    <input type="number" id="balance" name="balance" class="form-control" 
                        value="<?php echo e(old('balance') && old('balance') <= $lead->balance ? old('balance') : $lead->balance); ?>" 
                        min="0" step="0.01" required>
                            <?php $__errorArgs = ['balance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="deal_item" class="form-label">Deal Item</label>
                        <input type="text" id="deal_item" name="deal_item" class="form-control" value="<?php echo e(old('deal_item', $lead->deal_item)); ?>">
                        <?php $__errorArgs = ['deal_item'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php else: ?>
                    <!-- Hidden inputs to retain current values -->
                    <input type="hidden" name="rate" value="<?php echo e($lead->rate); ?>">
                    <input type="hidden" name="balance" value="<?php echo e($lead->balance); ?>">
                    <input type="hidden" name="deal_item" value="<?php echo e($lead->deal_item); ?>">
                <?php endif; ?>

                <!-- Action Buttons -->
                <div class="mt-4">
                    <button type="submit" class="btn btn-success">Update Lead</button>
                    <a href="<?php echo e(route('agent.lead.details', $lead->id)); ?>" class="btn btn-secondary">Back to Lead Details</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('agentlogin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Desktop\New folder\telecall-crm\resources\views/agentlogin/leadsdetailedit.blade.php ENDPATH**/ ?>