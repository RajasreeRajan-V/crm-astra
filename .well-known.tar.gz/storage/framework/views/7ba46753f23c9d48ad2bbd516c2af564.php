

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1 class="mb-4">Agents</h1>
    <a href="<?php echo e(route('agents.create')); ?>" class="btn btn-primary mb-3">Add New Agent</a>
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone No</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($agent->name); ?></td>
                        <td><?php echo e($agent->email); ?></td>
                        <td><?php echo e($agent->phone_no); ?></td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                            <a href="<?php echo e(route('agents.show', $agent->id)); ?>" class="btn btn-info btn-sm">View</a>
                            <a href="<?php echo e(route('agents.edit', $agent->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                            <form action="<?php echo e(route('agents.destroy', $agent->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this agent?')">Delete</button>
                            </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Desktop\New folder\telecall-crm\resources\views/agents/index.blade.php ENDPATH**/ ?>