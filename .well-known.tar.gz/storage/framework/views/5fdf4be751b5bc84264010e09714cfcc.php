
<?php $__env->startSection('content'); ?>
<style>
    .table-striped tbody tr:nth-of-type(odd) {
        background-color: rgba(0, 0, 0, 0.05);
    }

    .add-btn {
        margin-top: 20px;
        margin-bottom: 20px;
    }

    .filter-form {
        margin-bottom: 20px;
    }

    .filter-btn {
        margin-top: 30px;
    }

    .cancel-btn {
        margin-top: 30px;
    }
</style>

<!-- Main Content -->
<div class="content mt-5">
    <h1>Call Logs</h1>

    <!-- Filter Form -->
    <form method="GET" action="<?php echo e(route('agent.callLogs')); ?>" class="row filter-form">
        <div class="col-md-4">
            <label for="lead_name" class="form-label">Lead Name</label>
            <input type="text" name="lead_name" id="lead_name" class="form-control" value="<?php echo e(request('lead_name')); ?>">
        </div>
        <div class="col-md-4">
            <label for="call_date" class="form-label">Call Date</label>
            <input type="date" name="call_date" id="call_date" class="form-control" value="<?php echo e(request('call_date')); ?>">
        </div>
        <div class="col-md-4 d-flex gap-2">
            <button type="submit" class="btn btn-primary filter-btn">Filter</button>
            <a href="<?php echo e(route('agent.callLogs')); ?>" class="btn btn-secondary cancel-btn">Cancel</a>
        </div>
    </form>

    <!-- Button to Add Call Log -->
    <a href="<?php echo e(route('agent.calllog.create')); ?>" class="btn btn-primary add-btn">Add Call Log</a>

    <?php if($callLogs->isEmpty()): ?>
        <p>No call logs found.</p>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Lead Name</th> <!-- Updated -->
                    <th>Call Time</th>
                    <th>Duration</th>
                    <th>Notes</th>
                    <th>Outcome</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $callLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($log->lead->name ?? 'N/A'); ?></td> <!-- Display Lead Name -->
                        <td><?php echo e($log->call_time); ?></td>
                        <td><?php echo e($log->duration); ?></td>
                        <td><?php echo e($log->notes); ?></td>
                        <td><?php echo e($log->outcome); ?></td>
                        <td class="d-flex align-items-center">
                            <!-- Edit Button -->
                            <a href="<?php echo e(route('agent.calllog.edit', $log->id)); ?>" class="btn btn-warning btn-sm me-2">Edit</a>

                            <!-- Delete Button -->
                            <form action="<?php echo e(route('agent.calllog.delete', $log->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this call log?');" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('agentlogin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home1/astradevelops/public_html/crm.astradevelops.in/resources/views/agentlogin/callindex.blade.php ENDPATH**/ ?>