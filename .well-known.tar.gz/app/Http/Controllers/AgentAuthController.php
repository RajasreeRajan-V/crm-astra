<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AgentAuthController extends Controller
{
    public function showLoginForm()
    {
        return view('auth.agent-login'); // Create this view for agent login
    }

    public function login(Request $request)
    {
        $credentials = $request->only('phone_no', 'password');

        if (Auth::guard('agent')->attempt($credentials)) {
            return redirect()->intended('/agent/dashboard'); // Adjust the path as needed
        }

        return back()->withErrors(['phone_no' => 'Invalid credentials.']);
    }

    public function logout()
    {
        Auth::guard('agent')->logout();
        return redirect('/agent/login');
    }
}
